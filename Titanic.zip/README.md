This is Kunlin's README.md

This is a project about studying the survival of the titanic passengers.
